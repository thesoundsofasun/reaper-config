#!/usr/bin/env bash
set -e

echo "Looking for theme files..."

# 1. Find ANY .ReaperTheme file
THEME_FILE_PATH=$(find . -maxdepth 1 -name "*.ReaperTheme" | head -n 1)

# 2. Find the theme image folder reliably by looking for rtconfig.txt
THEME_DIR_PATH=$(find . -maxdepth 2 -name "rtconfig.txt" | head -n 1)

if [[ -z "$THEME_FILE_PATH" || -z "$THEME_DIR_PATH" ]]; then
    echo "Error: Could not find a .ReaperTheme file and its image folder (missing rtconfig.txt)."
    exit 1
fi

# Clean up the paths to just get the exact names
THEME_FILE=$(basename "$THEME_FILE_PATH")
THEME_DIR=$(basename "$(dirname "$THEME_DIR_PATH")")

# --- SMART RENAMING ---
# Only rename if they aren't already named AEHAZE
if [[ "$THEME_FILE" != "AEHAZE.ReaperTheme" ]]; then
    echo "Renaming $THEME_FILE to AEHAZE.ReaperTheme..."
    mv "$THEME_FILE" "AEHAZE.ReaperTheme"
fi

if [[ "$THEME_DIR" != "AEHAZE" ]]; then
    echo "Renaming $THEME_DIR to AEHAZE..."
    mv "$THEME_DIR" "AEHAZE"
fi

TARGET="AEHAZE.ReaperTheme"

# --- SMART IMAGE INJECTION (RE-RUNNABLE) ---
echo "Injecting custom PNG images..."

# 1. Inject root PNGs (sitting right next to the script)
for img in *.png; do
    if [[ -f "$img" ]]; then
        echo " -> Copying $img into AEHAZE base folder..."
        cp -f "$img" "AEHAZE/"
    fi
done

# 2. Inject 100% PNGs into AEHAZE base folder
if [[ -d "100" ]]; then
    for img in 100/*.png; do
        if [[ -f "$img" ]]; then
            echo " -> Copying 100/ $(basename "$img") into AEHAZE base folder..."
            cp -f "$img" "AEHAZE/"
        fi
    done
fi

# 3. Inject scaled PNGs (150 and 200) into their respective subfolders
for scale in 150 200; do
    if [[ -d "$scale" ]]; then
        for img in "$scale"/*.png; do
            if [[ -f "$img" ]]; then
                echo " -> Copying $scale/ $(basename "$img") into AEHAZE/$scale/..."
                mkdir -p "AEHAZE/$scale"
                cp -f "$img" "AEHAZE/$scale/"
            fi
        done
    fi
done
# -------------------------------

# Fix Windows hidden line endings
sed -i 's/\r$//' "$TARGET"

echo "Injecting color customizations..."

# REAPER integer color calculations
BG=4144959           # 63 63 63
BG_SEL=11842740      # 180 180 180
PEAKS=16777215       # 255 255 255

F_BG2=0; F_BG=0; F_BGSEL1=0; F_BGSEL2=0
F_PKS1=0; F_PKS2=0; F_PKS_SEL1=0; F_PKS_SEL2=0
in_color_theme=0

# Enable case-insensitive matching
shopt -s nocasematch

# --- THE MAGIC HEX FONT HACKER ---
update_hex_font() {
    local key="$1"
    local orig_hex="$2"

    local header="${orig_hex:0:56}"

    local w1="${header:32:2}"
    local w2="${header:34:2}"
    local weight_val=$(( 16#$w2$w1 ))

    local font_hex=""
    if [ $weight_val -ge 600 ]; then
        font_hex="53462050726F205465787420426F6C64"
    else
        font_hex="53462050726F205465787400526567756C6172"
    fi

    while [ ${#font_hex} -lt 64 ]; do
        font_hex+="00"
    done
    font_hex="${font_hex:0:64}"

    local body="${header}${font_hex}"

    local sum=0
    for (( i=0; i<${#body}; i+=2 )); do
        sum=$((sum + 16#${body:i:2}))
    done
    local checksum=$(printf "%02X" $((sum % 256)))

    echo "${key}=${body}${checksum}"
}
# ---------------------------------

echo "Processing file and hacking binary fonts..."

while IFS= read -r line; do

    # Track Color Section
    if [[ "$line" =~ ^\[color\ theme\] ]]; then
        in_color_theme=1
        echo "$line"
        continue
    elif [[ "$line" =~ ^\[.*\] ]] && [[ $in_color_theme -eq 1 ]]; then
        [[ $F_BG2 -eq 0 ]] && echo "col_mi_bg2=$BG"
        [[ $F_BG -eq 0 ]] && echo "col_mi_bg=$BG"
        [[ $F_BGSEL1 -eq 0 ]] && echo "col_tr1_itembgsel=$BG_SEL"
        [[ $F_BGSEL2 -eq 0 ]] && echo "col_tr2_itembgsel=$BG_SEL"
        [[ $F_PKS1 -eq 0 ]] && echo "col_tr1_peaks=$PEAKS"
        [[ $F_PKS2 -eq 0 ]] && echo "col_tr2_peaks=$PEAKS"
        [[ $F_PKS_SEL1 -eq 0 ]] && echo "col_tr1_ps2=$PEAKS"
        [[ $F_PKS_SEL2 -eq 0 ]] && echo "col_tr2_ps2=$PEAKS"
        in_color_theme=0
    fi

    # 1. Image Folder Reference inside the config
    if [[ "$line" =~ ^ui_img= ]]; then echo "ui_img=AEHAZE"

    # 2. Colors
    elif [[ "$line" =~ ^col_mi_bg2= ]]; then echo "col_mi_bg2=$BG"; F_BG2=1
    elif [[ "$line" =~ ^col_mi_bg= ]]; then echo "col_mi_bg=$BG"; F_BG=1
    elif [[ "$line" =~ ^col_tr1_itembgsel= ]]; then echo "col_tr1_itembgsel=$BG_SEL"; F_BGSEL1=1
    elif [[ "$line" =~ ^col_tr2_itembgsel= ]]; then echo "col_tr2_itembgsel=$BG_SEL"; F_BGSEL2=1
    elif [[ "$line" =~ ^col_tr1_peaks= ]]; then echo "col_tr1_peaks=$PEAKS"; F_PKS1=1
    elif [[ "$line" =~ ^col_tr2_peaks= ]]; then echo "col_tr2_peaks=$PEAKS"; F_PKS2=1
    elif [[ "$line" =~ ^col_tr1_ps2= ]]; then echo "col_tr1_ps2=$PEAKS"; F_PKS_SEL1=1
    elif [[ "$line" =~ ^col_tr2_ps2= ]]; then echo "col_tr2_ps2=$PEAKS"; F_PKS_SEL2=1

    # 3. INTERCEPT BINARY FONT STRINGS
    elif [[ "$line" =~ ^([a-zA-Z0-9_]*font[a-zA-Z0-9_]*)=([0-9a-fA-F]{120,})$ ]]; then
        key="${BASH_REMATCH[1]}"
        hex_string="${BASH_REMATCH[2]}"
        update_hex_font "$key" "$hex_string"

    # 4. Handle plain text fonts
    elif [[ "$line" =~ ^([a-zA-Z0-9_]*font[a-zA-Z0-9_]*)= ]]; then
        key="${BASH_REMATCH[1]}"
        echo "${key}=SF Pro Text"

    else
        echo "$line"
    fi

done < "$TARGET" > temp.ReaperTheme

# Safety net for missing colors at End of File
if [[ $in_color_theme -eq 1 ]]; then
    [[ $F_BG2 -eq 0 ]] && echo "col_mi_bg2=$BG" >> temp.ReaperTheme
    [[ $F_BG -eq 0 ]] && echo "col_mi_bg=$BG" >> temp.ReaperTheme
    [[ $F_BGSEL1 -eq 0 ]] && echo "col_tr1_itembgsel=$BG_SEL" >> temp.ReaperTheme
    [[ $F_BGSEL2 -eq 0 ]] && echo "col_tr2_itembgsel=$BG_SEL" >> temp.ReaperTheme
    [[ $F_PKS1 -eq 0 ]] && echo "col_tr1_peaks=$PEAKS" >> temp.ReaperTheme
    [[ $F_PKS2 -eq 0 ]] && echo "col_tr2_peaks=$PEAKS" >> temp.ReaperTheme
    [[ $F_PKS_SEL1 -eq 0 ]] && echo "col_tr1_ps2=$PEAKS" >> temp.ReaperTheme
    [[ $F_PKS_SEL2 -eq 0 ]] && echo "col_tr2_ps2=$PEAKS" >> temp.ReaperTheme
fi

mv temp.ReaperTheme "$TARGET"

shopt -u nocasematch

echo "================================================="
echo "Done! The AEHAZE theme is updated and ready!"
